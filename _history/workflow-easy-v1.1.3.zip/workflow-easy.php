<?php
/**
 * Plugin Name: Workflow easy
 * Plugin URI:  https://example.com
 * Description: Adds hierarchical user levels and admin menu controls. The plugin creates a `workflow_superadmin` role on activation and allows the creation of additional levels, reordering, and per‑level admin menu visibility.
 * Version:     1.1.3
 * Author:      Thomas & Effie
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: workflow-easy
 *
 * @package WorkflowEasy
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Activation hook callback.
 *
 * Creates the `workflow_superadmin` role based on the administrator capabilities.
 * Assigns the activating administrator user to the superadmin role. Initializes
 * default settings for level order and menu visibility. According to WordPress
 * documentation, new roles should be created on activation and not on every
 * page load【709623388398262†L141-L160】.
 */
function workflow_easy_activate() {
    // Create superadmin role if it doesn't exist.
    $admin_role = get_role( 'administrator' );
    $caps       = $admin_role ? $admin_role->capabilities : array( 'read' => true );
    if ( ! get_role( 'workflow_superadmin' ) ) {
        add_role( 'workflow_superadmin', 'Workflow Superadmin', $caps );
    }

    // Initialize level structure if not already present.
    $levels = get_option( 'workflow_easy_levels' );
    if ( ! is_array( $levels ) ) {
        // The superadmin level is always at the top with order 0.
        $levels = array(
            'workflow_superadmin' => array(
                'name'  => 'Workflow Superadmin',
                'order' => 0,
            ),
        );
        update_option( 'workflow_easy_levels', $levels );
    }

    // Initialize menu visibility settings if not present. Each level will have
    // an associative array keyed by menu slug with boolean show/hide flags.
    $menus = get_option( 'workflow_easy_menus' );
    if ( ! is_array( $menus ) ) {
        $menus = array();
        update_option( 'workflow_easy_menus', $menus );
    }

    // Assign current user (activating user) to superadmin role if they were admin.
    if ( function_exists( 'wp_get_current_user' ) ) {
        $user = wp_get_current_user();
        if ( $user && in_array( 'administrator', (array) $user->roles, true ) ) {
            $user->add_role( 'workflow_superadmin' );
        }
    }
}
register_activation_hook( __FILE__, 'workflow_easy_activate' );

/**
 * Main plugin class.
 */
class Workflow_Easy {

    /**
     * Singleton instance.
     *
     * @var Workflow_Easy|null
     */
    protected static $instance = null;

    /**
     * Retrieve singleton instance.
     *
     * @return Workflow_Easy
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Construct plugin object. Hooks into WordPress actions and filters.
     */
    private function __construct() {
        // Add plugin settings page for superadmins.
        add_action( 'admin_menu', array( $this, 'register_admin_page' ) );

        // Filter admin menu for non‑superadmin roles based on settings.
        // remove_menu_page must be called on the `admin_menu` hook【160043855559898†L70-L100】.
        add_action( 'admin_menu', array( $this, 'filter_admin_menu' ), 999 );
    }

    /**
     * Register the plugin's admin menu page.
     */
    public function register_admin_page() {
        // Only allow superadmins to access settings. Use capability slug equal to our role.
        $capability = 'workflow_superadmin';
        add_menu_page(
            __( 'Workflow easy', 'workflow-easy' ),
            __( 'Workflow easy', 'workflow-easy' ),
            $capability,
            'workflow-easy',
            array( $this, 'render_admin_page' ),
            'dashicons-admin-generic',
            90
        );
    }

    /**
     * Render the plugin's admin page with forms for managing levels and menus.
     */
    public function render_admin_page() {
        // Only superadmins may proceed.
        if ( ! current_user_can( 'workflow_superadmin' ) ) {
            wp_die( __( 'You do not have sufficient permissions to access this page.', 'workflow-easy' ) );
        }

        // Handle form submissions.
        $this->handle_form_submission();

        $levels = get_option( 'workflow_easy_levels', array() );
        $menus  = get_option( 'workflow_easy_menus', array() );

        // Sort levels by order ascending.
        // Use a comparator compatible with older PHP versions (avoid the spaceship operator <=>).
        uasort( $levels, function ( $a, $b ) {
            if ( $a['order'] == $b['order'] ) {
                return 0;
            }
            return ( $a['order'] < $b['order'] ) ? -1 : 1;
        } );

        // Collect available admin menu slugs and labels.
        global $menu;
        $available_menus = array();
        if ( is_array( $menu ) ) {
            foreach ( $menu as $item ) {
                if ( isset( $item[2] ) && ! empty( $item[2] ) ) {
                    $slug = $item[2];
                    $title = isset( $item[0] ) ? wp_strip_all_tags( $item[0] ) : $slug;
                    $available_menus[ $slug ] = $title;
                }
            }
        }

        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Workflow easy – Manage User Levels', 'workflow-easy' ); ?></h1>

            <h2><?php esc_html_e( 'Add New Level', 'workflow-easy' ); ?></h2>
            <form method="post">
                <?php wp_nonce_field( 'workflow_easy_add_level', 'workflow_easy_add_level_nonce' ); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="level_name"><?php esc_html_e( 'Level name', 'workflow-easy' ); ?></label></th>
                        <td><input type="text" name="level_name" id="level_name" class="regular-text" required></td>
                    </tr>
                </table>
                <?php submit_button( __( 'Add Level', 'workflow-easy' ), 'primary', 'workflow_easy_add_level' ); ?>
            </form>

            <h2><?php esc_html_e( 'Existing Levels', 'workflow-easy' ); ?></h2>
            <form method="post">
                <?php wp_nonce_field( 'workflow_easy_update_levels', 'workflow_easy_update_levels_nonce' ); ?>
                <table class="widefat fixed" style="max-width: 600px;">
                    <thead>
                    <tr>
                        <th><?php esc_html_e( 'Level', 'workflow-easy' ); ?></th>
                        <th><?php esc_html_e( 'Order', 'workflow-easy' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'workflow-easy' ); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ( $levels as $slug => $data ) : ?>
                        <tr>
                            <td><?php echo esc_html( $data['name'] ); ?></td>
                            <td><input type="number" name="level_order[<?php echo esc_attr( $slug ); ?>]" value="<?php echo intval( $data['order'] ); ?>" style="width: 60px;"></td>
                            <td>
                                <?php if ( 'workflow_superadmin' !== $slug ) : ?>
                                    <button type="submit" name="workflow_easy_delete_level" value="<?php echo esc_attr( $slug ); ?>" class="button-delete" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to delete this level?', 'workflow-easy' ); ?>');">
                                        <?php esc_html_e( 'Delete', 'workflow-easy' ); ?>
                                    </button>
                                <?php else : ?>
                                    <?php esc_html_e( 'Fixed', 'workflow-easy' ); ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php submit_button( __( 'Save Order', 'workflow-easy' ), 'primary', 'workflow_easy_save_order' ); ?>
            </form>

            <h2><?php esc_html_e( 'Menu Visibility', 'workflow-easy' ); ?></h2>
            <form method="post">
                <?php wp_nonce_field( 'workflow_easy_update_menus', 'workflow_easy_update_menus_nonce' ); ?>
                <table class="widefat fixed striped">
                    <thead>
                    <tr>
                        <th><?php esc_html_e( 'Menu Item', 'workflow-easy' ); ?></th>
                        <?php foreach ( $levels as $slug => $data ) : ?>
                            <th><?php echo esc_html( $data['name'] ); ?></th>
                        <?php endforeach; ?>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $row_idx = 0; foreach ( $available_menus as $slug => $title ) : ?>
                        <?php
                        // Add alternate class on every other row for better readability.
                        $row_class = ( $row_idx % 2 ) ? 'alternate' : '';
                        $row_idx++;
                        ?>
                        <tr class="<?php echo esc_attr( $row_class ); ?>">
                            <td><?php echo esc_html( $title ); ?></td>
                            <?php foreach ( $levels as $level_slug => $data ) : ?>
                                <td style="text-align: center;">
                                    <?php
                                    // For superadmin we always show, so no checkbox.
                                    if ( 'workflow_superadmin' === $level_slug ) {
                                        echo '&#x2713;';
                                    } else {
                                        $checked = ( isset( $menus[ $level_slug ] ) && isset( $menus[ $level_slug ][ $slug ] ) && $menus[ $level_slug ][ $slug ] ) ? 'checked' : '';
                                        echo '<input type="checkbox" name="workflow_easy_menu[' . esc_attr( $level_slug ) . '][' . esc_attr( $slug ) . ']" value="1" ' . $checked . ' />';
                                    }
                                    ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php submit_button( __( 'Save Menu Visibility', 'workflow-easy' ), 'primary', 'workflow_easy_save_menus' ); ?>
            </form>
        </div>
        <?php
    }

    /**
     * Handle form submissions for adding, deleting and ordering levels, and menu visibility.
     */
    private function handle_form_submission() {
        // Add new level.
        if ( isset( $_POST['workflow_easy_add_level'] ) && check_admin_referer( 'workflow_easy_add_level', 'workflow_easy_add_level_nonce' ) ) {
            // Retrieve the posted level name without using the null coalescing operator for wider PHP compatibility.
            $posted_name = isset( $_POST['level_name'] ) ? $_POST['level_name'] : '';
            $name = sanitize_text_field( wp_unslash( $posted_name ) );
            if ( $name ) {
                $slug = 'workflow_' . sanitize_title( $name );
                $levels = get_option( 'workflow_easy_levels', array() );
                if ( ! isset( $levels[ $slug ] ) ) {
                    // New role inherits minimal capabilities (read) by default.
                    add_role( $slug, $name, array( 'read' => true ) );
                    // Determine next order (highest order + 1).
                    $orders = wp_list_pluck( $levels, 'order' );
                    $max_order = $orders ? max( $orders ) : 0;
                    $levels[ $slug ] = array( 'name' => $name, 'order' => (int) $max_order + 1 );
                    update_option( 'workflow_easy_levels', $levels );
                }
            }
        }
        // Save ordering of levels.
        if ( isset( $_POST['workflow_easy_save_order'] ) && check_admin_referer( 'workflow_easy_update_levels', 'workflow_easy_update_levels_nonce' ) ) {
            if ( isset( $_POST['level_order'] ) && is_array( $_POST['level_order'] ) ) {
                $levels = get_option( 'workflow_easy_levels', array() );
                foreach ( $_POST['level_order'] as $slug => $order ) {
                    if ( isset( $levels[ $slug ] ) ) {
                        $levels[ $slug ]['order'] = (int) $order;
                    }
                }
                update_option( 'workflow_easy_levels', $levels );
            }
        }
        // Delete level.
        if ( isset( $_POST['workflow_easy_delete_level'] ) ) {
            $slug_to_delete = sanitize_text_field( wp_unslash( $_POST['workflow_easy_delete_level'] ) );
            if ( $slug_to_delete && 'workflow_superadmin' !== $slug_to_delete ) {
                // Remove role and associated menu settings.
                remove_role( $slug_to_delete );
                $levels = get_option( 'workflow_easy_levels', array() );
                unset( $levels[ $slug_to_delete ] );
                update_option( 'workflow_easy_levels', $levels );
                $menus = get_option( 'workflow_easy_menus', array() );
                unset( $menus[ $slug_to_delete ] );
                update_option( 'workflow_easy_menus', $menus );
            }
        }
        // Save menu visibility settings.
        if ( isset( $_POST['workflow_easy_save_menus'] ) && check_admin_referer( 'workflow_easy_update_menus', 'workflow_easy_update_menus_nonce' ) ) {
            $new_settings = array();
            if ( isset( $_POST['workflow_easy_menu'] ) && is_array( $_POST['workflow_easy_menu'] ) ) {
                foreach ( $_POST['workflow_easy_menu'] as $level_slug => $menu_slugs ) {
                    $new_settings[ sanitize_key( $level_slug ) ] = array();
                    foreach ( $menu_slugs as $slug => $value ) {
                        $new_settings[ $level_slug ][ sanitize_text_field( $slug ) ] = true;
                    }
                }
            }
            update_option( 'workflow_easy_menus', $new_settings );
        }
    }

    /**
     * Hide admin menu items for users based on the plugin's settings.
     * Runs late in the admin_menu hook to ensure other plugins have registered
     * their menus. According to the WordPress developer documentation the
     * remove_menu_page() function should be called on the admin_menu hook and
     * not before【160043855559898†L94-L99】.
     */
    public function filter_admin_menu() {
        // Superadmins see everything.
        if ( current_user_can( 'workflow_superadmin' ) ) {
            return;
        }

        $levels = get_option( 'workflow_easy_levels', array() );
        $menus  = get_option( 'workflow_easy_menus', array() );

        // Determine the highest priority level for the current user. The level
        // with the lowest order number has highest priority.
        $user   = wp_get_current_user();
        $roles  = (array) $user->roles;
        $level_slug = null;
        $current_order = PHP_INT_MAX;
        foreach ( $levels as $slug => $info ) {
            if ( in_array( $slug, $roles, true ) && $info['order'] < $current_order ) {
                $level_slug    = $slug;
                $current_order = $info['order'];
            }
        }
        if ( ! $level_slug ) {
            return;
        }
        // Get the list of menu slugs to show (checked) for this level.
        $allowed = isset( $menus[ $level_slug ] ) ? $menus[ $level_slug ] : array();
        // Build global $menu to remove those not allowed.
        global $menu;
        if ( ! is_array( $menu ) ) {
            return;
        }
        foreach ( $menu as $index => $item ) {
            $slug = isset( $item[2] ) ? $item[2] : '';
            // If slug not allowed, remove it for this role.
            if ( ! empty( $slug ) && 'index.php' !== $slug ) { // always keep Dashboard
                if ( ! isset( $allowed[ $slug ] ) ) {
                    remove_menu_page( $slug );
                }
            }
        }
    }
}

// Initialize plugin.
Workflow_Easy::get_instance();
=== Workflow easy ===
Contributors: Thomas and Effie
Tags: user roles, capabilities, admin menu, hierarchy
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.3.1
License: GPLv2 or later

Workflow easy lets administrators define custom user levels and control which
admin menus each level can access. When activated, the plugin creates a
`workflow_superadmin` role (copied from the built‑in administrator role) and
assigns the activating user to this new role. Only users with this role can
access the plugin’s settings. Within the settings you can create
additional levels, reorder them, and toggle visibility of admin menu items
per level. The top‑most level is always `workflow_superadmin`.

== Installation ==

1. Download the plugin ZIP file and upload it via **Plugins → Add New → Upload**.
2. Activate the plugin. The activating administrator will be assigned the
   `workflow_superadmin` role.
3. Under **Workflow easy** in the admin menu, configure your user levels and
   menu permissions.

== Frequently Asked Questions ==

*Why create another “superadmin” role?*

The role created by this plugin is unrelated to WordPress multisite’s built‑in
“Super Admin”. We use a separate role so that the plugin can be used on
single‑site installations and the role can be managed independently from
the multisite network administrator capability.

== Changelog ==

= 1.3.1 =
* Removed the blank separator rows that WordPress inserts into the admin menu from the **Menu Visibility** table. Only real menu items now appear in the list of menus that can be toggled.
* Improved how update counts are stripped from menu titles. The plugin now removes both numeric counts and counts wrapped in parentheses (e.g., “Tillägg 1” or “Tillägg (1)”), ensuring that only the menu name is displayed.
* Adjusted the alternating row colour to a lighter shade for a subtler, cleaner look while keeping rows easy to distinguish.

= 1.3.0 =
* Added improved visual styling to the **Menu Visibility** table. Every other row now has a slightly darker background colour for better readability.
* Removed the numeric update badge from the Plugins (Tillägg) menu title in the Menu Visibility table. WordPress automatically adds a count of available updates (e.g., “Tillägg 1”), which cluttered the interface. The plugin now strips this count and shows only the menu name.
* Tweaked spacing in the admin page and table headers to reduce unnecessary blank space and create a more compact layout.

= 1.2.0 =
* The “Existing Levels” and “Menu Visibility” interfaces now show all WordPress user roles (administrator, editor, author, contributor, subscriber, etc.) alongside the custom levels created by this plugin. Built‑in roles cannot be deleted, but their menu access can be configured just like plugin‑defined levels. The plugin now merges these roles internally so that menu visibility restrictions can apply to any role.

= 1.1.3 =
* Standardised the plugin folder name to `workflow-easy` for consistent upgrades. Previously, versioned directories (e.g. `workflow-easy-v1.1.2`) created duplicate plugins, causing fatal errors when functions were redeclared. New releases now overwrite the existing plugin when uploaded. If you have multiple Workflow easy entries, deactivate and remove older versions before activating this one.

= 1.1.2 =
* Fixed a fatal error on activation caused by the use of newer PHP syntax (null coalescing and spaceship operators). The plugin now uses syntax compatible with older PHP versions, ensuring it activates correctly on hosts running PHP 5.x.

= 1.1.1 =
* Added `CHANGELOG.md` file.
* Enhanced the menu visibility table to include alternating row colours for improved readability.

= 1.1.0 =
* Updated the Menu Visibility interface to display all levels in a single matrix with a column per level.
* Added the ability to edit menu visibility for all levels at once.

= 1.0.0 =
* Initial release.
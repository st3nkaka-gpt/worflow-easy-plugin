# Changelog

All notable changes to this project will be documented in this file. The format
is based on [Keep a Changelog](https://keepachangelog.com/) and this project
adheres to [Semantic Versioning](https://semver.org/).

## [1.1.2] - 2025-08-05
### Fixed
- Resolved a fatal error on activation when running under older PHP versions (prior to PHP 7). The plugin now avoids the use of the null coalescing operator (`??`) and the spaceship operator (`<=>`) by implementing compatible alternatives. This change ensures the plugin can be activated on hosts still running PHP 5.x without syntax errors.

## [1.1.1] - 2025-08-05
### Added
- Introduced this `CHANGELOG.md` file so future updates are documented.
- Improved the Menu Visibility table by adding alternating row colours for
  enhanced readability in the WordPress admin.

## [1.1.0] - 2025-08-05
### Added
- Updated the Menu Visibility interface to display all user levels at once. Each
  level now has its own column with checkboxes, allowing the superadmin to
  manage what each level can see in a single matrix.
- Added UI improvements including a striped table style to visually separate
  rows.

## [1.0.0] - 2025-08-05
### Added
- Initial release of Workflow easy. Provided functionality to create a
  `workflow_superadmin` role on activation, create additional levels, reorder
  them, and control per–level visibility of admin menu items.
=== Workflow easy ===
Contributors: Thomas and Effie
Tags: user roles, capabilities, admin menu, hierarchy
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.1.2
License: GPLv2 or later

Workflow easy lets administrators define custom user levels and control which
admin menus each level can access. When activated, the plugin creates a
`workflow_superadmin` role (copied from the built‑in administrator role) and
assigns the activating user to this new role. Only users with this role can
access the plugin’s settings. Within the settings you can create
additional levels, reorder them, and toggle visibility of admin menu items
per level. The top‑most level is always `workflow_superadmin`.

== Installation ==

1. Download the plugin ZIP file and upload it via **Plugins → Add New → Upload**.
2. Activate the plugin. The activating administrator will be assigned the
   `workflow_superadmin` role.
3. Under **Workflow easy** in the admin menu, configure your user levels and
   menu permissions.

== Frequently Asked Questions ==

*Why create another “superadmin” role?*

The role created by this plugin is unrelated to WordPress multisite’s built‑in
“Super Admin”. We use a separate role so that the plugin can be used on
single‑site installations and the role can be managed independently from
the multisite network administrator capability.

== Changelog ==

= 1.1.2 =
* Fixed a fatal error on activation caused by the use of newer PHP syntax (null coalescing and spaceship operators). The plugin now uses syntax compatible with older PHP versions, ensuring it activates correctly on hosts running PHP 5.x.

= 1.1.1 =
* Added `CHANGELOG.md` file.
* Enhanced the menu visibility table to include alternating row colours for improved readability.

= 1.1.0 =
* Updated the Menu Visibility interface to display all levels in a single matrix with a column per level.
* Added the ability to edit menu visibility for all levels at once.

= 1.0.0 =
* Initial release.